/** @type {import('tailwindcss').Config} */
const defaultTheme = require('tailwindcss/defaultTheme')

module.exports = {
  content: ["./src/**/*.{html,js}"],
  theme: {
    extend: {},
    fontFamily: {
      'main': ['Montserrat', ...defaultTheme.fontFamily.sans],
      'Vollkorn': ['Vollkorn', ...defaultTheme.fontFamily.sans]
    }
  },
  plugins: [],
}